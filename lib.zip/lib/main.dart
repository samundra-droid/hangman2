import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const RiddlerApp());
}

class RiddlerApp extends StatelessWidget {
  const RiddlerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Riddler',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false, // Debug tag removed
      home: const SplashScreen(isInitial: true),
    );
  }
}

class SplashScreen extends StatelessWidget {
  final bool isInitial;
  final bool playerWon;

  const SplashScreen({super.key, this.isInitial = false, this.playerWon = false});

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 3), () {
      if (isInitial) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const RiddlerHome()),
        );
      } else {
        Navigator.pop(context);
      }
    });

    return Scaffold(
      body: Container(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Riddler',
                style: const TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange,
                ),
              ),
              const SizedBox(height: 20),
              if (!isInitial)
                Text(
                  playerWon
                      ? 'Amazing Job! Ready for a tougher challenge? 🎉'
                      : 'Don\'t give up! Each attempt sharpens your skills. 💪',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              const SizedBox(height: 20),
              const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RiddlerHome extends StatefulWidget {
  const RiddlerHome({super.key});

  @override
  State<RiddlerHome> createState() => _RiddlerHomeState();
}

class _RiddlerHomeState extends State<RiddlerHome> {
  final List<Map<String, String>> _wordsWithHints = [
    {'word': 'FLUTTER', 'hint': 'A popular UI toolkit for mobile apps.'},
    {'word': 'WIDGET', 'hint': 'Building block of Flutter applications.'},
    {'word': 'DART', 'hint': 'Programming language for Flutter.'},
    {'word': 'MOBILE', 'hint': 'Platform for which Flutter is widely used.'},
  ];

  late String _selectedWord;
  late String _selectedHint;
  late List<String> _displayedWord;
  Set<String> _guessedLetters = {};
  int _wrongGuesses = 0;
  final int _maxWrongGuesses = 6;
  bool _gameOver = false;
  bool _playerWon = false;

  @override
  void initState() {
    super.initState();
    _startNewGame();
  }

  void _startNewGame() {
    setState(() {
      final selected = _wordsWithHints[Random().nextInt(_wordsWithHints.length)];
      _selectedWord = selected['word']!;
      _selectedHint = selected['hint']!;
      _displayedWord = List.filled(_selectedWord.length, '_');
      _guessedLetters.clear();
      _wrongGuesses = 0;
      _gameOver = false;
      _playerWon = false;
    });
  }

  void _guessLetter(String letter) {
    if (_gameOver || _guessedLetters.contains(letter)) return;

    setState(() {
      _guessedLetters.add(letter);
      if (_selectedWord.contains(letter)) {
        for (int i = 0; i < _selectedWord.length; i++) {
          if (_selectedWord[i] == letter) {
            _displayedWord[i] = letter;
          }
        }
        if (!_displayedWord.contains('_')) {
          _playerWon = true;
          _gameOver = true;
          _showEndGameSplash();
        }
      } else {
        _wrongGuesses++;
        if (_wrongGuesses >= _maxWrongGuesses) {
          _gameOver = true;
          _showEndGameSplash();
        }
      }
    });
  }

  void _showEndGameSplash() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SplashScreen(isInitial: false, playerWon: _playerWon),
      ),
    ).then((_) => _startNewGame());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          'Riddler',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.orange),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            color: Colors.black,
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNavBarButton('Play Online', true),
                _buildNavBarButton('App', false),
                _buildNavBarButton('Web Gadget', false),
                _buildNavBarButton('Support', false),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const Text(
                  "Welcome to Riddler - the ultimate word puzzle experience!",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                Text(
                  'Hint: $_selectedHint',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.orange,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blue),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'Word: ${_displayedWord.join(' ')}',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Wrong guesses: $_wrongGuesses/$_maxWrongGuesses',
                        style: const TextStyle(fontSize: 18),
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 8.0,
                        runSpacing: 8.0,
                        children: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((letter) {
                          return ElevatedButton(
                            onPressed: _guessedLetters.contains(letter) || _gameOver
                                ? null
                                : () => _guessLetter(letter),
                            child: Text(letter),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _startNewGame,
                        child: const Text('Play Again'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          Container(
            color: Colors.grey.shade200,
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const [
                Text('Terms of Service'),
                Text('Copyright © 2024 Riddler'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavBarButton(String title, bool isSelected) {
    return TextButton(
      onPressed: isSelected ? null : () {},
      child: Text(
        title,
        style: TextStyle(color: isSelected ? Colors.orange : Colors.white),
      ),
    );
  }
}
